package com.example.firstapp;

public class Constant {
    static final String php = "http://192.168.43.234";
}
